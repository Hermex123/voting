<?php
include('header.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Voting System</title>
</head>
<body>
	<div style="margin-top: 170px;"></div>
     <div class="container-fluid">
     	<div class="col-md-12">
     		<div class="row">
     			
     			<div class="col-md-11"> 
     				<div class="row">
     					<div class="col-md-8 wow zoomIn">
     						<h4><u>How to vote</u></h4>
                   <p>Thank you for registering our application and we are glad to see you, we will tech you how to vote is our system slowly and understandable .<br>Here are the step you need to follow before you can vote successfully.</p>

                   <br>
                   <ol>
                   	<li>Create an account.</li>
                    <img src="img/create_account.png" class="shadow my-5" style="width:137%">
                   	<li>Log into your account.</li>
                    <img src="img/login3.png" class="shadow my-5" style="width:137%">
                   	<li>Click on profile at the menu bar.</li>
                    <img src="img/profile.png" class="shadow my-5" style="width:137%">
                   	<li>Check Voters ID.</li>
                    <img src="img/id.png" class="shadow my-5" style="width:137%">
                   	<li>Copy or Keep it in your mind.</li>
                   	<li>Click on vote at the menu bar.</li>
                     <img src="img/vote.png" class="shadow my-5"style="width:137%">
                    <li>View all contestant avialable</li>
                     <img src="img/con1.png" class="shadow my-5"style="width:137%">
                    <li>Click on Start Voting.</li>
                     <img src="img/start.png" class="shadow my-5"style="width:137%">
                   	<li>Type your Voters ID.</li>
                      <img src="img/st.png" class="shadow my-5" style="width:137%">
                   	
                   </ol>
     					</div>
     					<div class="col-md-4 wow fadeInRight ">
     				
     					</div>
     				</div>

                   <br>
                   <br>
                   <h4 class="wow zoomIn">Rules And Regulations</h4>
                   <br>
                   <ol class="wow zoomIn">
                   	<li>Do not waste alot of time during voting.</li>
                   	<li>Do not Go Back when vote.</li>
                   	<li>Do not try to Revote after voting.</li>
                    <li>Do not try to vote with someone Voters ID.</li>
                   </ol>
                   <p></p>
     			</div>
     		</div>
     	</div>
     </div>
</body>
</html>

